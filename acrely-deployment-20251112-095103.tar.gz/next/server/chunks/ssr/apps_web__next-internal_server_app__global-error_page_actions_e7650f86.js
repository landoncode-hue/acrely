module.exports=[12695,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app__global-error_page_actions_e7650f86.js.map