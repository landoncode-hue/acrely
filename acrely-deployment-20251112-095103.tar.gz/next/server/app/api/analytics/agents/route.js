var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/analytics/agents/route.js")
R.c("server/chunks/[root-of-the-server]__7ccac70e._.js")
R.c("server/chunks/[root-of-the-server]__a6997b27._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_analytics_agents_route_actions_1914774f.js")
R.m(15044)
module.exports=R.m(15044).exports
