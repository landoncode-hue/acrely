module.exports=[19379,a=>{"use strict";function b({children:a}){return a}a.s(["default",()=>b,"dynamic",0,"force-dynamic"])}];

//# sourceMappingURL=apps_web_app_dashboard_field-reports_layout_tsx_710f284d._.js.map