module.exports=[60919,a=>{"use strict";function b({children:a}){return a}a.s(["default",()=>b,"dynamic",0,"force-dynamic"])}];

//# sourceMappingURL=apps_web_app_dashboard_analytics_layout_tsx_87913c3d._.js.map