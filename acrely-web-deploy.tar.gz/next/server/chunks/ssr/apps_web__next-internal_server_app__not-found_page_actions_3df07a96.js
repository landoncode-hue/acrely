module.exports=[27559,(a,b,c)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app__not-found_page_actions_3df07a96.js.map