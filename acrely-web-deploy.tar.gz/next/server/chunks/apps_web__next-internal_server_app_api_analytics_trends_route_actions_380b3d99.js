module.exports=[40259,(e,o,d)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_api_analytics_trends_route_actions_380b3d99.js.map