module.exports=[50815,(e,o,d)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_api_analytics_estates_route_actions_84cf5c8f.js.map