var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/analytics/summary/route.js")
R.c("server/chunks/[root-of-the-server]__2f0f28e0._.js")
R.c("server/chunks/[root-of-the-server]__a6997b27._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_analytics_summary_route_actions_e8135a8c.js")
R.m(72873)
module.exports=R.m(72873).exports
