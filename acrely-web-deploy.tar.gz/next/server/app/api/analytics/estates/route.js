var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/analytics/estates/route.js")
R.c("server/chunks/[root-of-the-server]__befc6e26._.js")
R.c("server/chunks/[root-of-the-server]__a6997b27._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_analytics_estates_route_actions_84cf5c8f.js")
R.m(60590)
module.exports=R.m(60590).exports
