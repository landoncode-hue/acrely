var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/analytics/trends/route.js")
R.c("server/chunks/[root-of-the-server]__c7be5316._.js")
R.c("server/chunks/[root-of-the-server]__a6997b27._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_analytics_trends_route_actions_380b3d99.js")
R.m(91202)
module.exports=R.m(91202).exports
